CREATE DATABASE FACTURACIONFERNEY;

USE FACTURACIONFERNEY;

CREATE TABLE cliente(
id_cliente VARCHAR (30) UNIQUE PRIMARY KEY,
nombre VARCHAR (25) UNIQUE NOT NULL,
apellido VARCHAR (25) UNIQUE NOT NULL,
direccion VARCHAR(20) NOT NULL,
telefono VARCHAR(20) NOT NULL,
correo VARCHAR(50) UNIQUE NOT NULL,
municipio VARCHAR(20),
departamento VARCHAR(20),
pais VARCHAR (20) CHECK (pais='Colombia'), 
creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE factura(
num_factura VARCHAR (20) UNIQUE PRIMARY KEY,
id_cliente VARCHAR (30),
id_producto VARCHAR (30),
creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente)
);

CREATE TABLE productos(
id_producto VARCHAR (30) UNIQUE PRIMARY KEY,
nombre VARCHAR (25) NOT NULL,
precio INT (25) NOT NULL,
stock INT (25) NOT NULL,
num_factura VARCHAR (20),
creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
FOREIGN KEY (num_factura) REFERENCES factura(num_factura)
);
ALTER TABLE factura ADD FOREIGN KEY(id_producto) REFERENCES
productos(id_producto);

-- CLIENTE
INSERT INTO cliente (id_cliente, nombre, apellido, direccion, telefono, 
correo, municipio, departamento, pais)
VALUES ('900876543-0', 'JUAN', 'GOMEZ', 'CALLE 13', '8608978', 
'USER1@USER1.COM', 'QUEBRADAS', 'RISARALDA', 'COLOMBIA');
INSERT INTO cliente (id_cliente, nombre, apellido, direccion, telefono, 
correo, municipio, departamento, pais)
VALUES ('800876543-0', 'CAMILO', 'VELEZ', 'CALLE 11', '87098765', 
'USER2@USER2.COM', 'ORITO', 'PUTUMAYO', 'COLOMBIA');
INSERT INTO cliente (id_cliente, nombre, apellido, direccion, telefono, 
correo, municipio, departamento, pais)
VALUES ('1077654345', 'JUANA', 'DE ARCO', 'CALLE 10', '861876567', 
'USER3@USER3.COM', 'BOGOTÁ', 'CUNDINAMARCA', 'COLOMBIA');

-- FACTURA
INSERT INTO factura (num_factura, id_cliente)
VALUES ('A-001', '900876543-0');
INSERT INTO factura (num_factura, id_cliente)
VALUES ('A-002', '1077654345');
INSERT INTO factura (num_factura, id_cliente)
VALUES ('A-003', '800876543-0');
-- No se insertan valores para la columna id_producto, debido a que, al ser 

llave foránea, estos valores deben primero crearse en la tabla original de 
productos.

--PRODUCTOS
INSERT INTO productos (id_producto, nombre, precio, stock, num_factura)
VALUES ('PRO-001', 'PORTÁTIL', '2800000', '70', 'A-001');
INSERT INTO productos (id_producto, nombre, precio, stock, num_factura)
VALUES ('PRO-002', 'TECLADO', '30000', '30', 'A-002');
INSERT INTO productos (id_producto, nombre, precio, stock, num_factura)
VALUES ('PRO-003', 'MOUSE', '15000', '20', 'A-003');

-- Ahora vamos a actualizar la columna id_producto de la tabla factura.

UPDATE factura SET id_producto = 'PRO-001' WHERE num_factura = 'A-001';
UPDATE factura SET id_producto = 'PRO-002' WHERE num_factura = 'A-002';
UPDATE factura SET id_producto = 'PRO-003' WHERE num_factura = 'A-003';

SELECT
 *
 FROM cliente
 INNER JOIN factura ON cliente.id_cliente = factura.id_cliente;

 SELECT
*
FROM cliente
LEFT JOIN factura ON cliente.id_cliente = factura.id_cliente;

SELECT
*
FROM cliente
LEFT JOIN factura ON cliente.id_cliente = factura.id_cliente WHERE
factura.id_cliente IS NULL;

SELECT
*
FROM cliente
RIGHT JOIN factura ON cliente.id_cliente = factura.id_cliente;

SELECT
*
FROM cliente
RIGHT JOIN factura ON cliente.id_cliente = factura.id_cliente WHERE
factura.id_cliente IS NULL;


CREATE DATABASE JUEGO_DE_ARMAS;

USE JUEGO_DE_ARMAS;

CREATE TABLE CALLDUTY(
    id_juegador VARCHAR (30) UNIQUE PRIMARY KEY,
    nombre VARCHAR (30) UNIQUE NOT NULL,
    correo VARCHAR (50) UNIQUE NOT NULL,
    contraseña VARCHAR (25) UNIQUE NOT NULL,
    pregunta_de_seguridad VARCHAR(50) UNIQUE NOT NULL,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE personaje(
    id_personaje VARCHAR (30) UNIQUE PRIMARY KEY,
    nombre_personaje VARCHAR (30) UNIQUE NOT NULL,
    id_juegador VARCHAR (30),
    caracteristica VARCHAR (25) UNIQUE NOT NULL,
    cantida_de_utilisaciones VARCHAR(50) UNIQUE NOT NULL,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_juegador) REFERENCES CALLDUTY(id_juegador)
);

CREATE TABLE mapas(
    id_mapas VARCHAR (30) UNIQUE PRIMARY KEY,
    id_partidas VARCHAR (30),
    locaciones VARCHAR (50),
    estrutura VARCHAR (25) UNIQUE NOT NULL,
    buson_de_mejoras VARCHAR(50) UNIQUE NOT NULL,
    FOREIGN KEY (id_partidas) REFERENCES partidas(id_partidas),
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE partidas(
    id_partidas VARCHAR (30) UNIQUE PRIMARY KEY,
    id_juegador VARCHAR (30),
    id_personaje VARCHAR (30),
    contraseña VARCHAR (25) UNIQUE NOT NULL,
    pregunta_de_seguridad VARCHAR(50) UNIQUE NOT NULL,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_personaje) REFERENCES personaje(id_personaje)
);

ALTER TABLE partidas ADD FOREIGN KEY(id_juegador) REFERENCES CALLDUTY(id_juegador);

SELECT * FROM CALLDUTY INNER JOIN partidas ON CALLDUTY.id_juegador = partidas.id_juegador;
SELECT * FROM CALLDUTY LEFT JOIN partidas ON CALLDUTY.id_juegador = partidas.id_juegador;
SELECT * FROM CALLDUTY RIGHT JOIN partidas ON CALLDUTY.id_juegador = partidas.id_juegador;

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña,pregunta_de_seguridad)
VALUES ('1245', 'JUAN', 'USER1@USER1.COM', 'QUEBRADAS', 'soy yo con mki perro?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('2356', 'MARIA', 'USER2@USER2.COM', '123456', 'nombre de mi mascota?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('5432', 'PEDRO', 'USER3@USER3.COM', 'CONTRASEÑA', 'color favorito?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('9876', 'ANA', 'USER4@USER4.COM', 'MI1234', 'ombre de mi mascota?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('6543', 'CARLOS', 'USER@USER5.COM', 'QUERADAS', 'ciudad de nacimiento?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('7890', 'LAURA', 'USER@USER1.COM', '12356', 'oy yo con mki perro?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('4321', 'MARTIN', 'USE@USER2.COM', 'CONTRAEÑA', 'clor favorito?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('8765', 'SOFIA', 'USER@USER3.COM', 'MI134', 'iudad de nacimiento?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('1357', 'LUIS', 'USER@USER4.COM', 'QUEBRDAS', 'nombe de mi mascota?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('2468', 'ISABEL', 'USER@USER.COM', '12886', 'soy o con mki perro?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('5321', 'ANi', 'USER@USER6.COM', 'CONTRASEÑA12', 'cidad de nacmiento?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('9867', 'DAVID', 'USER7@USER7.COM', 'DAVID123', 'nombr de mi mascota?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('7893', 'SARA', 'USER8@USER8.COM', 'SARA456', 'soy yo con m perro?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('1293', 'MIGUEL', 'USER9@USER9.COM', 'MIGUEL789', 'color favoio?');

INSERT INTO CALLDUTY (id_juegador, nombre, correo, contraseña, pregunta_de_seguridad) 
VALUES ('7456', 'LUCIA', 'USER10@USER10.COM', 'LUCIA2023', 'cidad de nacimiento?');

INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-001', '1245');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-002', '2356');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-003', '5432');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-004', '9876');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-005', '6543');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-006', '7890');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-007', '4321');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-008', '8765');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-009', '1357');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-010', '2468');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-011', '5321');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-012', '9867');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-013', '7893');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-014', '1293');
INSERT INTO partidas (id_partidas, id_cliente)
VALUES ('A-015', '7456');

INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-001', 'joner', 'chaqueta negra', '2', 'A-01');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-002', 'joner', 'chaqueta azul', '2', 'A-02');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-003', 'joner', 'chaqueta roja', '2', 'A-03');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-004', 'joner', 'chaqueta vaquera', '2', 'A-04');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-005', 'joner', 'chaqueta ocura', '2', 'A-05');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-006', 'joner', 'chaqueta 158', '2', 'A-06');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-007', 'joner', 'chaqueta rock', '2', 'A-07');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-008', 'joner', 'chaqueta 65p-', '2', 'A-08');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-009', 'joner', 'chaqueta modelo', '2', 'A-09');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-010', 'joner', 'chaqueta amierica', '2', 'A-010');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-011', 'joner', 'chaqueta latina', '2', 'A-011');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-012', 'joner', 'chaqueta india', '2', 'A-012');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-013', 'joner', 'chaqueta sueca', '2', 'A-013');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-014', 'joner', 'chaqueta agertina', '2', 'A-014');
INSERT INTO personaje (id_personaje, nombre_personaje, caracteristica, cantida_de_utilisaciones, id_partidas)
VALUES ('PRO-015', 'joner', 'chaqueta hoak hace', '2', 'A-015');
